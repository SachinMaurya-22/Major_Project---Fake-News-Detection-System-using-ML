# Fake News Detection

This project implements a Fake News Detection system using Machine Learning. The system can classify news articles as **Real** or **Fake** based on their content.

---


