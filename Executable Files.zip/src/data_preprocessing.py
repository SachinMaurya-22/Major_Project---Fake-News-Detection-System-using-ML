# src/data_preprocessing.py

import re
import string

def preprocess_text(text):
    """
    Function to clean and preprocess news text.
    Steps:
    - Convert to lowercase
    - Remove punctuation
    - Remove extra spaces
    """
    text = str(text).lower()  # lowercase
    text = re.sub(f"[{re.escape(string.punctuation)}]", "", text)  # punctuation remove
    text = re.sub('\s+', ' ', text)  # multiple spaces replace with single space
    text = text.strip()
    return text
