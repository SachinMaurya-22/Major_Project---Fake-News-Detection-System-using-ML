# src/predict.py

import joblib
from data_preprocessing import preprocess_text

class FakeNewsPredictor:
    def __init__(self, model_path='logistic_model.pkl', vectorizer_path='vectorizer.pkl'):
        self.model = joblib.load(model_path)
        self.vectorizer = joblib.load(vectorizer_path)

    def predict(self, news_list):
        """
        news_list: list of raw news strings
        returns: list of predictions (0 = real, 1 = fake)
        """
        processed_news = [preprocess_text(news) for news in news_list]
        vect_news = self.vectorizer.transform(processed_news)
        preds = self.model.predict(vect_news)
        return preds.tolist()

if __name__ == "__main__":
    # Example usage:
    predictor = FakeNewsPredictor()
    sample_news = [
        "Breaking: New vaccine shows 99% effectiveness!",
        "Aliens have landed on Earth, government confirms."
    ]
    predictions = predictor.predict(sample_news)
    for news, pred in zip(sample_news, predictions):
        label = "Fake" if pred == 1 else "Real"
        print(f"News: {news}\nPrediction: {label}\n")
