# src/model.py

import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report
import joblib
from data_preprocessing import preprocess_text  # apne preprocessing function ko import kar rahe hain

class FakeNewsModel:
    def __init__(self):
        self.vectorizer = TfidfVectorizer(max_features=5000)
        self.model = LogisticRegression(max_iter=1000)

    def load_data(self, filepath):
        data = pd.read_csv(filepath)
        data['text'] = data['text'].apply(preprocess_text)
        return data

    def train(self, train_path, test_path):
        train_data = self.load_data(train_path)
        test_data = self.load_data(test_path)

        X_train = self.vectorizer.fit_transform(train_data['text'])
        y_train = train_data['label']

        X_test = self.vectorizer.transform(test_data['text'])
        y_test = test_data['label']

        self.model.fit(X_train, y_train)

        y_pred = self.model.predict(X_test)

        print(f"Test Accuracy: {accuracy_score(y_test, y_pred):.4f}")
        print("\nClassification Report:\n", classification_report(y_test, y_pred))

        # Save model and vectorizer
        joblib.dump(self.model, 'logistic_model.pkl')
        joblib.dump(self.vectorizer, 'vectorizer.pkl')
        print("Model and vectorizer saved!")

    def predict(self, texts):
        """
        Predict if given news texts are fake or real.
        texts: list of raw news strings
        returns: list of predictions (0 = real, 1 = fake)
        """
        clean_texts = [preprocess_text(text) for text in texts]
        vect_texts = self.vectorizer.transform(clean_texts)
        preds = self.model.predict(vect_texts)
        return preds.tolist()

# Usage example (if running as script):
if __name__ == "__main__":
    fn_model = FakeNewsModel()
    fn_model.train('../data/train.csv', '../data/test.csv')
