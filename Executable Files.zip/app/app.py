# app/app.py

from flask import Flask, request, render_template
import sys
import os
sys.path.append(os.path.abspath("../src"))  # src folder ko import path me add kar diya

from predict import FakeNewsPredictor

app = Flask(__name__)
predictor = FakeNewsPredictor(
    model_path="../src/logistic_model.pkl", 
    vectorizer_path="../src/vectorizer.pkl"
)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    news_text = request.form['news']
    prediction = predictor.predict([news_text])[0]
    label = "Fake" if prediction == 1 else "Real"
    return render_template('index.html', prediction=label, news=news_text)

if __name__ == '__main__':
    app.run(debug=True)
